// Mobilmeny toggle
document.getElementById("menu-toggle").addEventListener("click", () => {
  document.getElementById("nav-links").classList.toggle("active");
});

// Navbar scroll-effekt
window.addEventListener("scroll", () => {
  const navbar = document.getElementById("navbar");
  if (window.scrollY > 50) {
    navbar.classList.add("scrolled");
  } else {
    navbar.classList.remove("scrolled");
  }
});

// Kontaktformulär - enkel bekräftelse
document.querySelector(".contact-form").addEventListener("submit", function (e) {
  e.preventDefault();
  alert("Tack för ditt meddelande! Vi återkommer så snart vi kan.");
  this.reset();
});
